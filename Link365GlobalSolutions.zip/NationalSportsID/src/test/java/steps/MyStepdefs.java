package steps;

import engine.Driver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.nio.file.FileStore;
import java.util.List;

//import static org.junit.Assert.assertTrue;

public class MyStepdefs {

    //variable declaration for our WebDriver
    private WebDriver driver;
    private FileStore selenium;

    //initialization of the driver
    public MyStepdefs (Driver driver){
        this.driver = driver.get();
    }

    @Given("Input all the fields")
    //public void thereIsAnAvailableStockOfAProduct() {
      public void inputAlltheFields() {
        driver.get("http://test.nationalsportsid.com/register?type=2&embed=0");
        String ActualTitle = driver.getTitle();
        WebElement playerFirstname = driver.findElement(By.id("firstName"));
        playerFirstname.sendKeys("DOMINIC");
        WebElement playerLastname = driver.findElement(By.id("lastName"));
        playerLastname.sendKeys("LARGO");
        WebElement playerBirthdate = driver.findElement(By.id("birthDate"));
        playerBirthdate.sendKeys("04/27/1984");
    }

    @When("I click the 'Submit' button")
    public void iClicktheSubmitbutton() {
        driver.findElement(By.id("submit-child")).click();
        driver.findElement(By.id("new-player")).click();
        driver.findElement(By.id("next-step")).click();

    }


    @When("I input parent fields")
    public void iInputParent() {
        WebElement parentFirstname = driver.findElement(By.id("hoopalert_user_parent_registration_firstName"));
        parentFirstname.sendKeys("ParentFirstname");
        WebElement parentLastname = driver.findElement(By.id("hoopalert_user_parent_registration_lastName"));
        parentLastname.sendKeys("ParentLastname");
        WebElement parentAddress = driver.findElement(By.id("hoopalert_user_parent_registration_address_addressLine"));
        parentAddress.sendKeys("Minglanilla");
        WebElement parentCity = driver.findElement(By.id("hoopalert_user_parent_registration_address_city"));
        parentCity.sendKeys("Cebu");
        WebElement parentState = driver.findElement(By.id("hoopalert_user_parent_registration_address_state"));
        parentState.sendKeys("Kalubihan");
        WebElement parentZipCode = driver.findElement(By.id("hoopalert_user_parent_registration_address_zipCode"));
        parentZipCode.sendKeys("3000");
        Select drpCountry = new Select(driver.findElement(By.name("hoopalert_user_parent_registration[address][country]")));
        drpCountry.selectByVisibleText("Philippines");
        Select drpTimezone = new Select(driver.findElement(By.name("hoopalert_user_parent_registration[timezone]")));
        drpTimezone.selectByVisibleText("UTC");
        WebElement parentEmail = driver.findElement(By.id("hoopalert_user_parent_registration_email"));
        parentEmail.sendKeys("largodomz@gmail.com");
        WebElement parentPass = driver.findElement(By.id("hoopalert_user_parent_registration_plainPassword_first"));
        parentPass.sendKeys("aaaaa11111");
        WebElement parentPass2 = driver.findElement(By.id("hoopalert_user_parent_registration_plainPassword_second"));
        parentPass2.sendKeys("aaaaa11111");
        driver.findElement(By.xpath("//label[@for='hoopalert_user_parent_registration_enableMode_0']")).click();
        WebElement parentMobile = driver.findElement(By.id("hoopalert_user_parent_registration_phoneNumbers_0_phoneNumber"));
        parentMobile.sendKeys("+639053959863");
        driver.findElement(By.xpath("//label[@for='hoopalert_user_parent_registration_terms']")).click();
        driver.findElement(By.id("register")).click();

    }


    @Then("I see Verify Account page")
    public void iSeeVerifyAcct(){
        //declaration for WebDriverWait variable which is used in our explicit wait
        WebDriverWait wait = new WebDriverWait(driver, 30);

        driver.navigate().to("http://test.nationalsportsid.com/profile/edit/verify");
        //Assert.assertEquals(Boolean.TRUE,wait);

    }
}